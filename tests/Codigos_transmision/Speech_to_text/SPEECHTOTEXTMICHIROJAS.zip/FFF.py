import os
import glob
import time
import requests
import re
from datetime import datetime

# Configuración inicial de AssemblyAI
base_url = "https://api.assemblyai.com"
headers = {
    "authorization": "d912768f271d49e8b0157f7083944b62"
}

# Obtener la ruta de la carpeta "Documents" del usuario actual
documents_folder = os.path.join(os.environ["USERPROFILE"], "Documents")

# Ruta de la carpeta que contiene los audios
audio_folder = os.path.join(documents_folder, "audio")

# Extensiones soportadas
audio_extensions = ['*.wav']

# Buscar archivos en la carpeta que coincidan con las extensiones especificadas
files = []
for ext in audio_extensions:
    files.extend(glob.glob(os.path.join(audio_folder, ext)))

if not files:
    raise FileNotFoundError("No se encontraron archivos de audio en la carpeta.")

# Seleccionar el archivo de audio añadido o modificado más recientemente
latest_file = max(files, key=os.path.getctime)
print(f"Utilizando el archivo de audio: {latest_file}")

# Subir el archivo local a AssemblyAI
with open(latest_file, "rb") as f:
    upload_response = requests.post(base_url + "/v2/upload", headers=headers, data=f)
    upload_response.raise_for_status()

audio_url = upload_response.json()["upload_url"]

# Datos para solicitar la transcripción
data = {
    "audio_url": audio_url,
    "speech_model": "universal"
}

# Solicitar la transcripción al API de AssemblyAI
transcript_endpoint = base_url + "/v2/transcript"
response = requests.post(transcript_endpoint, json=data, headers=headers)
response.raise_for_status()

transcript_id = response.json()['id']
polling_endpoint = base_url + f"/v2/transcript/{transcript_id}"

# Bucle de sondeo del estado de la transcripción
while True:
    transcription_result = requests.get(polling_endpoint, headers=headers).json()

    if transcription_result['status'] == 'completed':
        transcription_text = transcription_result['text']
        print("Texto de la transcripción:")
        print(transcription_text)
        
        # Directorio donde se guardarán las transcripciones en archivos .txt
        transcript_folder = os.path.join(documents_folder, "transcript")
        
        # Crear la carpeta si no existe
        if not os.path.exists(transcript_folder):
            os.makedirs(transcript_folder)
        
        # Buscar archivos .txt cuyo nombre sea un número seguido de un guion bajo (ej. "1_01-01-2025_10-00-00.txt")
        txt_files = [filename for filename in os.listdir(transcript_folder) if re.match(r'^\d+_', filename)]
        max_number = 0
        for filename in txt_files:
            number = int(re.match(r'^(\d+)_', filename).group(1))  # Extraer el número inicial del nombre del archivo
            if number > max_number:
                max_number = number
        new_number = max_number + 1

        # Obtener la fecha y hora actuales
        timestamp = datetime.now().strftime("%d-%m-%Y_%H-%M-%S")

        # Crear el nombre del archivo con el formato "número_fecha-hora.txt"
        new_filename = os.path.join(transcript_folder, f"{new_number}_{timestamp}.txt")
        
        # Guardar el texto de la transcripción en el archivo
        with open(new_filename, "w", encoding="utf-8") as outfile:
            outfile.write(transcription_text)
            
        print(f"La transcripción se ha guardado en el archivo: {new_filename}")
        break

    elif transcription_result['status'] == 'error':
        raise RuntimeError(f"La transcripción ha fallado: {transcription_result['error']}")
    else:
        time.sleep(3)

