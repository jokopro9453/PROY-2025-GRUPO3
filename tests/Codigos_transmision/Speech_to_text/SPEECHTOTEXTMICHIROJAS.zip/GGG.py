import os
import re
from datetime import datetime
from fuzzywuzzy import fuzz

# Obtener la ruta de la carpeta "Documents" del usuario actual
documents_folder = os.path.join(os.environ["USERPROFILE"], "Documents")

# ------------------------
# Parte 1: Extraer la contraseña desde el archivo en la carpeta user
# ------------------------
user_folder = os.path.join(documents_folder, "user")

# Verificar que la carpeta user exista
if not os.path.exists(user_folder):
    raise Exception(f"La carpeta de usuarios no existe: {user_folder}")

# Obtener el archivo de usuario (se asume que solo hay uno)
user_files = [f for f in os.listdir(user_folder) if f.endswith(".txt")]
if not user_files:
    raise Exception(f"No se encontró ningún archivo de usuario en la carpeta: {user_folder}")

user_file_path = os.path.join(user_folder, user_files[0])

# Leer la contraseña desde el archivo
with open(user_file_path, "r", encoding="utf-8") as uf:
    lines = uf.readlines()
    if len(lines) < 4:
        raise Exception(f"El archivo de usuario no contiene una contraseña válida: {user_file_path}")
    stored_password = lines[3].strip()  # La contraseña está en la cuarta línea

print("Contraseña leída del archivo:", stored_password)

# ------------------------
# Parte 2: Leer la transcripción más reciente
# ------------------------
transcript_folder = os.path.join(documents_folder, "transcript")
if not os.path.exists(transcript_folder):
    raise Exception(f"La carpeta de transcripciones no existe: {transcript_folder}")

# Verificar que la carpeta de transcripciones exista
if not os.path.exists(transcript_folder):
    raise Exception(f"No se encontró el directorio de transcripciones: {transcript_folder}")

# Buscar archivos de transcripción en el directorio
txt_files = [f for f in os.listdir(transcript_folder) if f.endswith(".txt")]

# Manejar el caso en que no haya archivos de transcripción
if not txt_files:
    print("No se encontró ningún archivo de transcripción en el directorio. Asegúrate de que existan archivos .txt.")
else:
    # Obtener el archivo más reciente basado en la fecha de modificación
    latest_file = max(txt_files, key=lambda f: os.path.getmtime(os.path.join(transcript_folder, f)))
    transcript_path = os.path.join(transcript_folder, latest_file)

    # Leer el contenido del archivo de transcripción
    with open(transcript_path, "r", encoding="utf-8") as file:
        transcribed_text = file.read().strip()

    print("Archivo de transcripción encontrado:", transcript_path)
    print("Texto transcripto:", transcribed_text)

# ------------------------
# Normalizar los textos para la comparación
# ------------------------
def normalize_text(text):
    # Convertir a minúsculas
    text = text.lower()
    # Eliminar puntuación (puntos, comas, etc.)
    text = re.sub(r"[^\w\s]", "", text)
    # Eliminar espacios adicionales
    text = re.sub(r"\s+", " ", text).strip()
    return text

# Normalizar la contraseña y el texto transcripto
normalized_password = normalize_text(stored_password)
normalized_transcription = normalize_text(transcribed_text)

# ------------------------
# Parte 3: Comparar la contraseña y el texto transcripto con fuzzywuzzy
# ------------------------
similarity = fuzz.ratio(normalized_password, normalized_transcription)
print(f"Similitud: {similarity}%")

# ------------------------
# Parte 4: Evaluar la similitud (umbral de aprobación >=85%)
# ------------------------
if similarity >= 85:
    result_message = "Contraseña aprobada"
else:
    result_message = "Contraseña denegada"
print(result_message)

# ------------------------
# Parte 5: Guardar el resultado en un archivo .txt en el directorio de respuestas
# ------------------------
respuestas_folder = os.path.join(documents_folder, "respuestas")
if not os.path.exists(respuestas_folder):
    os.makedirs(respuestas_folder)

# Buscar archivos existentes con nombres numéricos (ej. "1.txt", "2.txt", etc.)
respuesta_files = [f for f in os.listdir(respuestas_folder) if re.match(r'^\d+_', f)]
max_number = 0
for f in respuesta_files:
    num = int(re.match(r'^(\d+)_', f).group(1))  # Extraer el número inicial del nombre del archivo
    if num > max_number:
        max_number = num
new_number = max_number + 1

# Obtener la fecha y hora actuales
timestamp = datetime.now().strftime("%d-%m-%Y_%H-%M-%S")

# Crear el nombre del archivo con el formato "número_fecha-hora.txt"
respuesta_filename = os.path.join(respuestas_folder, f"{new_number}_{timestamp}.txt")

# Guardar el resultado en el archivo
with open(respuesta_filename, "w", encoding="utf-8") as outfile:
    outfile.write(f"Porcentaje de similitud: {similarity}%\n")
    outfile.write(result_message)

print(f"El resultado se ha guardado en: {respuesta_filename}")

