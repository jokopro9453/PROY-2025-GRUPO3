from flask import Flask, request, jsonify
import subprocess
import os

app = Flask(__name__)

# Obtener la ruta de la carpeta "Documents" del usuario actual
documents_folder = os.path.join(os.environ["USERPROFILE"], "Documents")

@app.route('/webhook', methods=['POST'])
def webhook():
    data = request.get_json(force=True)
    
    # Se espera que el update incluya la clave "audio_recibido"
    if data.get("audio_recibido"):
        try:
            # Ruta de los scripts
            fff_script = os.path.join(documents_folder, "FFF.py")
            ggg_script = os.path.join(documents_folder, "GGG.py")

            # Ejecutar FFF.py
            if os.path.exists(fff_script):
                subprocess.run(["python", fff_script], cwd= os.path.join(documents_folder), check=True)
                print("FFF.py ejecutado con éxito.")
            else:
                return jsonify({"error": f"El archivo {fff_script} no existe."}), 500

            # Ejecutar GGG.py
            if os.path.exists(ggg_script):
                subprocess.run(["python", ggg_script], cwd= os.path.join(documents_folder), check=True)
                print("GGG.py ejecutado con éxito.")
            else:
                return jsonify({"error": f"El archivo {ggg_script} no existe."}), 500

            return jsonify({"status": "Estado comprobado en la base de datos de Werner"}), 200
        except subprocess.CalledProcessError as e:
            return jsonify({"error": "Error al ejecutar los scripts.", "details": str(e)}), 500
        except Exception as e:
            return jsonify({"error": "Error inesperado.", "details": str(e)}), 500
    else:
        return jsonify({"status": "No se recibió la clave 'audio_recibido'."}), 400

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)