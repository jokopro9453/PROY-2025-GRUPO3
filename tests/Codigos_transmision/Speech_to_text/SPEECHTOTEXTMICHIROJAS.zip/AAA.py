import os
import requests
import uuid
from datetime import datetime
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, CallbackContext

# Configurar el token del bot
TOKEN = "EL_TOKEN_AQUI"  # Reemplazar con el token de Mitchell Rojas

# Obtener la ruta de la carpeta "Documents" del usuario actual
documents_folder = os.path.join(os.environ["USERPROFILE"], "Documents")

# Ruta de la carpeta para almacenar usuarios
user_folder = os.path.join(documents_folder, "user")
os.makedirs(user_folder, exist_ok=True)

# Ruta de la carpeta para almacenar logs
logs_folder = os.path.join(documents_folder, "logs")
os.makedirs(logs_folder, exist_ok=True)

# Ruta de la carpeta para almacenar audios
audio_folder = os.path.join(documents_folder, "audio")
os.makedirs(audio_folder, exist_ok=True)

# Obtener la MAC del dispositivo
def get_mac_address():
    return ':'.join(['{:02x}'.format((uuid.getnode() >> i) & 0xff) for i in range(0, 8 * 6, 8)][::-1])

# Verificar si ya hay un usuario registrado con la misma MAC
def is_user_registered():
    for file in os.listdir(user_folder):
        file_path = os.path.join(user_folder, file)
        with open(file_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
            if len(lines) >= 2:
                registered_mac = lines[1].strip()  # La MAC está en la segunda línea
                if registered_mac == get_mac_address():
                    return True  # Usuario registrado con la misma MAC
                else:
                    return "MAC_DIFERENTE"  # Usuario registrado con una MAC diferente
    return False

# Obtener el nombre del usuario registrado con la misma MAC
def get_registered_username():
    for file in os.listdir(user_folder):
        file_path = os.path.join(user_folder, file)
        with open(file_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
            if len(lines) >= 2 and lines[1].strip() == get_mac_address():
                return lines[0].strip()  # El nombre del usuario está en la primera línea
    return None

# Comando /start
async def start(update: Update, context: CallbackContext):
    registration_status = is_user_registered()
    if registration_status == "MAC_DIFERENTE":
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text="Ya hay un usuario registrado para el candado, intente con el dispositivo adecuado."
        )
        return
    elif registration_status:
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text="Puede enviar un archivo de audio para abrir tu candado."
        )
        return

    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text="Hola, soy Michi Rojas tu bot de seguridad avanzada. Regístrate primero poniendo tu usuario con el comando: /user (nombre)."
    )

# Comando /user
async def register_user(update: Update, context: CallbackContext):
    try:
        registration_status = is_user_registered()
        if registration_status == "MAC_DIFERENTE":
            await update.message.reply_text("Ya hay un usuario registrado para el candado, intente con el dispositivo adecuado.")
            return

        if len(context.args) != 1:
            await update.message.reply_text("Por favor, proporciona tu nombre de usuario con el comando: /user (nombre).")
            return

        username = context.args[0]
        mac_address = get_mac_address()
        registration_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Verificar si ya existe un archivo de usuario
        user_files = [os.path.join(user_folder, f) for f in os.listdir(user_folder) if f.endswith(".txt")]
        if user_files:
            # Guardar los datos del usuario actual en usuario_antiguo.txt
            old_user_file = user_files[0]
            with open(old_user_file, "r", encoding="utf-8") as f:
                old_user_data = f.read()

            log_file = os.path.join(logs_folder, "usuario_antiguo.txt")
            with open(log_file, "a", encoding="utf-8") as log:
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                log.write(f"[{timestamp}] Usuario antiguo:\n{old_user_data}\n")

            # Eliminar el archivo del usuario actual
            os.remove(old_user_file)

        # Crear un nuevo archivo para el usuario
        user_file = os.path.join(user_folder, f"{username}.txt")
        with open(user_file, "w", encoding="utf-8") as f:
            f.write(f"{username}\n{mac_address}\n{registration_time}\n")

        await update.message.reply_text(
            f"Usuario registrado: {username}\nMAC: {mac_address}\nHora de registro: {registration_time}\n"
            "Ahora escribe la contraseña que será almacenada en la base de datos para la comparación con el comando: /password (contraseña)."
        )
    except Exception as e:
        await update.message.reply_text(f"Error: {str(e)}")

# Comando /password
async def set_password(update: Update, context: CallbackContext):
    try:
        # Verificar si el usuario está registrado
        username = get_registered_username()
        if not username:
            await update.message.reply_text("Primero debes registrarte con el comando: /user (nombre).")
            return

        # Verificar si se proporcionaron argumentos
        if not context.args:
            await update.message.reply_text("Por favor, proporciona tu contraseña con el comando: /password (contraseña).")
            return

        # Unir todos los argumentos para permitir contraseñas con espacios
        new_password = " ".join(context.args)

        # Buscar el archivo del usuario registrado
        user_file = os.path.join(user_folder, f"{username}.txt")
        if not os.path.exists(user_file):
            await update.message.reply_text("No se encontró el archivo del usuario registrado. Por favor, regístrate nuevamente.")
            return

        # Leer el archivo del usuario
        with open(user_file, "r", encoding="utf-8") as f:
            lines = f.readlines()

        # Asegurarse de que el archivo tenga al menos 4 líneas
        while len(lines) < 4:
            lines.append("\n")  # Agregar líneas vacías si faltan

        # Obtener la contraseña antigua (si existe)
        old_password = lines[3].strip() if lines[3].strip() else "Ninguna"

        # Reemplazar la contraseña en la cuarta línea
        lines[3] = f"{new_password}\n"

        # Guardar la nueva contraseña en el archivo del usuario
        with open(user_file, "w", encoding="utf-8") as f_write:
            f_write.writelines(lines)

        # Guardar la contraseña antigua en un archivo de logs
        log_file = os.path.join(logs_folder, "contra_antigua.txt")
        with open(log_file, "a", encoding="utf-8") as log:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            log.write(f"[{timestamp}] Usuario: {username}, Contraseña antigua: {old_password}\n")

        # Responder al usuario
        await update.message.reply_text("Contraseña actualizada correctamente. Ahora puedes enviar un mensaje de voz para procesarlo.")
    except Exception as e:
        # Manejar errores y responder al usuario
        await update.message.reply_text(f"Error: {str(e)}")

# Manejar mensajes de voz
async def voice_message_handler(update: Update, context: CallbackContext):
    # Verificar si el usuario está registrado
    username = get_registered_username()
    if not username:
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text="No estás registrado. Por favor, regístrate primero con el comando /user (nombre)."
        )
        return

    # Obtener el archivo de voz
    voice = update.message.voice
    file_id = voice.file_id

    # Obtener la fecha y hora actuales
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

    # Crear el nombre del archivo con el formato "usuario_fecha_hora.wav"
    audio_filename = f"{username}_{timestamp}.wav"
    audio_path = os.path.join(audio_folder, audio_filename)

    # Descargar el archivo de voz
    new_file = await context.bot.get_file(file_id)
    await new_file.download_to_drive(audio_path)

    # Enviar el file_id al servidor local con la clave "audio_recibido"
    server_url = "http://127.0.0.1:5000/webhook"
    try:
        response = requests.post(server_url, json={"audio_recibido": True, "file_id": file_id})
        if response.status_code == 200:
            server_response = response.json().get("status", "No se recibió respuesta del servidor.")
            await context.bot.send_message(chat_id=update.effective_chat.id, text=f"Conexión exitosa con el servidor: {server_response}")
        else:
            await context.bot.send_message(chat_id=update.effective_chat.id, text="Error al procesar el audio en el servidor.")
    except Exception as e:
        await context.bot.send_message(chat_id=update.effective_chat.id, text=f"Error: {str(e)}")

    # Enviar la confirmacion sobre el archivo al servidor para su procesamiento
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text=f"Procesando tu voz..."
    )

# Función principal
def main():
    # Crear la aplicación del bot
    application = Application.builder().token(TOKEN).build()

    # Agregar manejadores de comandos y mensajes
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("user", register_user))
    application.add_handler(CommandHandler("password", set_password))
    application.add_handler(MessageHandler(filters.VOICE, voice_message_handler))

    # Iniciar el bot
    application.run_polling()

if __name__ == "__main__":
    main()