
from flask import Flask, jsonify
import json
import os

app = Flask(__name__)

USERS_FILE = "users.json"
LOGS_FILE = "logs.json"

def load_json_file(filename):
    if not os.path.exists(filename):
        with open(filename, "w", encoding="utf-8") as f:
            json.dump([], f)
        return []
    with open(filename, "r", encoding="utf-8") as f:
        return json.load(f)

@app.route("/users", methods=["GET"])
def get_users():
    users = load_json_file(USERS_FILE)
    return jsonify(users)

@app.route("/logs", methods=["GET"])
def get_logs():
    logs = load_json_file(LOGS_FILE)
    return jsonify(logs)

if __name__ == "__main__":
    app.run(port=5000, debug=False)