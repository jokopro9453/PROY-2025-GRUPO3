import json
import os
from datetime import datetime, timedelta
from crypto_utils import encrypt_password, decrypt_password

DB_FILE = "users.json"

def load_users():
    if not os.path.exists(DB_FILE):
        return {}
    with open(DB_FILE, "r") as f:
        return json.load(f)

def save_users(users):
    with open(DB_FILE, "w") as f:
        json.dump(users, f, indent=2)

def register_user(telegram_id, username, mac):
    users = load_users()
    users[str(telegram_id)] = {
        "username": username,
        "mac": mac,
        "password": None,
        "use_random_password": True,
        "failed_attempts": 0,
        "last_failed_time": None,
        "block_until": None
    }
    save_users(users)

def set_password(telegram_id, password):
    users = load_users()
    if str(telegram_id) in users:
        users[str(telegram_id)]["password"] = encrypt_password(password)
        users[str(telegram_id)]["use_random_password"] = False
        save_users(users)
        return True
    return False

def set_random_password(telegram_id):
    users = load_users()
    if str(telegram_id) in users:
        users[str(telegram_id)]["use_random_password"] = True
        save_users(users)
        return True
    return False

def get_user(telegram_id):
    users = load_users()
    user = users.get(str(telegram_id))
    if user and user.get("password") and not user.get("use_random_password", True):
        try:
            user["password"] = decrypt_password(user["password"])
        except Exception:
            user["password"] = None
    return user

def get_failed_attempts(telegram_id):
    users = load_users()
    user = users.get(str(telegram_id))
    if user is None:
        return 0
    return user.get("failed_attempts", 0)

def increment_failed_attempts(telegram_id):
    users = load_users()
    user = users.get(str(telegram_id))
    if user is None:
        return
    user["failed_attempts"] = user.get("failed_attempts", 0) + 1
    user["last_failed_time"] = datetime.now().isoformat(timespec="seconds")
    save_users(users)

def reset_failed_attempts(telegram_id):
    users = load_users()
    user = users.get(str(telegram_id))
    if user is None:
        return
    user["failed_attempts"] = 0
    user["last_failed_time"] = None
    user["block_until"] = None
    save_users(users)

def set_block_until(telegram_id, block_until):
    users = load_users()
    user = users.get(str(telegram_id))
    if user is None:
        return
    user["block_until"] = block_until.isoformat(timespec="seconds")
    save_users(users)

def get_block_until(telegram_id):
    users = load_users()
    user = users.get(str(telegram_id))
    if user is None:
        return None
    return user.get("block_until")

def set_emergency_phone(telegram_id, phone):
    users = load_users()
    if str(telegram_id) in users:
        users[str(telegram_id)]["emergency_phone"] = phone
        save_users(users)
        return True
    return False

def get_emergency_phone(telegram_id):
    users = load_users()
    user = users.get(str(telegram_id))
    if user:
        return user.get("emergency_phone")
    return None