# Requiere instalar dependencias:
# Ejecuta en tu terminal:
#   pip install python-telegram-bot==20.0b0 python-dotenv fuzzywuzzy requests scipy y nose elimine el ressemblyzer en esta version
#   asi que nose si funciona (exceso de laburo)

# ===================== IMPORTS =====================
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters, CallbackQueryHandler
)
from dotenv import load_dotenv
from fuzzywuzzy import fuzz
import os
import requests
import json
import random
import speechtotxt as userpass

# --- FUNCIONALIDADES EXTRA ---
try:
    from users_db import (
        register_user, set_password, set_random_password, get_user,
        get_failed_attempts, increment_failed_attempts, reset_failed_attempts,
        set_block_until, get_block_until, set_emergency_phone, get_emergency_phone
    )
    from logs_db import add_log, get_logs_by_period
    from datetime import datetime, timedelta
    extra_features = True
except ImportError:
    extra_features = False

# ===================== PALABRAS Y CONFIG =====================
with open('palabras.json', 'r', encoding='utf-8') as f:
    data = json.load(f)
palabras = data['palabras']

def rpass():
    passwd = random.choice(palabras)
    return passwd

load_dotenv()
TELE_API = os.getenv("TELEGRAM_API")

# Url de la raspi
url = "http://192.168.45.32/led/on"
url2 = "http://192.168.45.32/led/off"

# Carpetas
audios_prueba = "audios_prueba"
audios_recibidos = "audios_recibidos"
os.makedirs(audios_prueba, exist_ok=True)
os.makedirs(audios_recibidos, exist_ok=True)

# ===================== HANDLERS ORIGINALES =====================
# Iniciar con el comando /start
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Interfaz bonita con instrucciones y botones
    keyboard = [
        [
            InlineKeyboardButton("Usar palabra aleatoria", callback_data='palabra_aleatoria'),
            InlineKeyboardButton("Usar palabra predefinida", callback_data='palabra_predefinida')
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    instrucciones = (
        "👋 ¡Bienvenido! Elige cómo quieres usar la contraseña de voz para abrir la cerradura.\n\n"
        "🔹 Si es tu primera vez, sigue estos pasos:\n"
        "1️⃣ Elige si quieres usar una palabra aleatoria o una predefinida.\n"
        "2️⃣ Graba y envía un mensaje de voz diciendo la palabra seleccionada.\n"
        "3️⃣ Si la voz y la palabra coinciden, la cerradura se abrirá.\n"
        "4️⃣ Puedes registrar tu usuario y MAC con /user <nombre_usuario>, (esto ademas registrara tu telefono actual).\n"
        "5️⃣ Puedes cambiar la contraseña con /password <contraseña> o usar /passwordrandom.\n"
        "ℹ️ Si tienes dudas, usa /help para ver los comandos."
    )
    if update.message:
        await update.message.reply_text(instrucciones, reply_markup=reply_markup)
    else:
        await update.effective_chat.send_message(instrucciones, reply_markup=reply_markup)

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    help_text = (
        "ℹ️ *Comandos disponibles:*\n\n"
        "/start - Muestra la interfaz principal\n"
        "/help - Muestra este mensaje de ayuda\n"
        "/user <nombre_usuario> - Registra tu usuario y MAC\n"
        "/password <contraseña> - Establece tu contraseña personalizada\n"
        "/passwordrandom - Usa una contraseña aleatoria\n"
        "/logs [day|week|month] - Muestra los últimos accesos (solo 5 min tras abrir el candado)\n\n"
        "También puedes usar los botones para seleccionar el tipo de contraseña y enviar un mensaje de voz para abrir la cerradura."
    )
    await update.message.reply_text(help_text)

# Handler para los botones de selección de tipo de palabra
async def palabra_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if query.data == 'palabra_aleatoria':
        passwd = rpass()
        context.user_data['passwd'] = passwd
        msg = (
            f"🔑 Has elegido usar una palabra aleatoria.\n"
            f"Tu contraseña de un solo uso es: >> {passwd} <<\n"
            "Envía un mensaje de voz diciendo esta palabra.\n\n"
            "🟢 Consejos:\n"
            "- Habla claro y sin ruido de fondo.\n"
            "- Si tienes problemas, repite el proceso."
        )
        await query.edit_message_text(msg)
    elif query.data == 'palabra_predefinida':
        msg = (
            "🔑 Has elegido usar una palabra predefinida.\n"
            "Para establecer tu palabra, usa el comando:\n"
            "/password <tu_palabra>\n"
            "Luego, envía un mensaje de voz diciendo esa palabra.\n\n"
            "🟢 Consejos:\n"
            "- Usa una palabra/frase no tan facil de adivinar.\n"
            "- Regístrate primero con /user <nombre_usuario>."
        )
        await query.edit_message_text(msg)

# --- MENÚ INTERACTIVO Y COMANDOS EXTRAS ---
last_open_time = {}

import json
import os

USERS_FILE = "users.json"

def load_users():
    if not os.path.exists(USERS_FILE):
        with open(USERS_FILE, "w", encoding="utf-8") as f:
            json.dump([], f)
        return []
    with open(USERS_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_users(users):
    with open(USERS_FILE, "w", encoding="utf-8") as f:
        json.dump(users, f, indent=2)

def register_user(telegram_id, username, mac):
    users = load_users()
    for user in users:
        if user["telegram_id"] == telegram_id:
            user["username"] = username
            user["mac"] = mac
            save_users(users)
            return
    users.append({
        "telegram_id": telegram_id,
        "username": username,
        "mac": mac,
        "password": "",
        "random_password": False
    })
    save_users(users)

def set_password(telegram_id, password):
    users = load_users()
    for user in users:
        if user["telegram_id"] == telegram_id:
            user["password"] = password
            user["random_password"] = False
            save_users(users)
            return True
    return False

def set_random_password(telegram_id):
    users = load_users()
    for user in users:
        if user["telegram_id"] == telegram_id:
            user["random_password"] = True
            save_users(users)
            return True
    return False

def get_user(telegram_id):
    users = load_users()
    for user in users:
        if user["telegram_id"] == telegram_id:
            return user
    return None

LOG_FILE = "logs.json"

def load_logs():
    if not os.path.exists(LOG_FILE):
        with open(LOG_FILE, "w", encoding="utf-8") as f:
            json.dump([], f)
        return []
    with open(LOG_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_logs(logs):
    with open(LOG_FILE, "w", encoding="utf-8") as f:
        json.dump(logs, f, indent=2)

def add_log(telegram_id, username, mac, password, result):
    logs = load_logs()
    from datetime import datetime
    logs.append({
        "telegram_id": telegram_id,
        "username": username,
        "mac": mac,
        "password": password,
        "result": result,
        "timestamp": datetime.now().isoformat(timespec="seconds")
    })
    save_logs(logs)

def get_logs_by_period(period="day"):
    logs = load_logs()
    from datetime import datetime, timedelta
    now = datetime.now()
    if period == "day":
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    elif period == "week":
        start = now - timedelta(days=now.weekday())
        start = start.replace(hour=0, minute=0, second=0, microsecond=0)
    elif period == "month":
        start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    else:
        return []
    return [log for log in logs if datetime.fromisoformat(log["timestamp"]) >= start]

# --- END JSON CREATION ---
    
async def user_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 1:
        await update.message.reply_text("Uso: /user <nombre_usuario>")
        return
    username = context.args[0]
    mac = str(update.effective_user.id)  # MAC obtenida automáticamente
    register_user(update.effective_user.id, username, mac)
    await update.message.reply_text(f"Usuario '{username}' registrado con MAC {mac}.")

async def password_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Uso: /password <contraseña>")
        return
    password = " ".join(context.args).lower()
    if set_password(update.effective_user.id, password):
        await update.message.reply_text("Contraseña establecida correctamente.")
    else:
        await update.message.reply_text("Primero debes registrarte con /user.")

async def passwordrandom_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if set_random_password(update.effective_user.id):
        await update.message.reply_text("Ahora se usará una contraseña aleatoria.")
    else:
        await update.message.reply_text("Primero debes registrarte con /user.")

async def logs_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    from datetime import datetime, timedelta
    now = datetime.now()
    if user_id not in last_open_time or (now - last_open_time[user_id]) > timedelta(minutes=5):
        await update.message.reply_text("Solo puedes consultar los logs hasta 5 minutos después de abrir el candado.")
        return
    period = "day"
    if context.args:
        if context.args[0] in ["day", "week", "month"]:
            period = context.args[0]
    logs = get_logs_by_period(period)
    user_logs = [log for log in logs if log["telegram_id"] == user_id]
    if not user_logs:
        await update.message.reply_text("No hay logs para mostrar.")
        return
    msg = f"Logs ({period}):\n"
    for log in user_logs[-10:]:
        msg += f"{log['timestamp']} - {log['result']} - MAC: {log['mac']} - Pass: {log['password']}\n"
    await update.message.reply_text(msg)

def notify_emergency(update, user):
    return "Funcionalidad de teléfono de emergencia deshabilitada."

def handle_blocking(update, user):
    telegram_id = update.effective_user.id
    failed = 0  # Puedes implementar intentos fallidos si lo deseas
    if failed >= 5:
        from datetime import datetime, timedelta
        block_minutes = 5 * (2 ** (failed - 5))
        block_until = datetime.now() + timedelta(minutes=block_minutes)
        # set_block_until(telegram_id, block_until)
        return f"Has superado el límite de intentos. Acceso bloqueado por {block_minutes} minutos."
    return None

def send_sound_command(sound_type):
    pass

# ===================== AUDIO BOT =====================
async def audio_bot(update: Update, context: ContextTypes.DEFAULT_TYPE):    
    try:
        file_path = os.path.join(audios_recibidos, "Audio_recibido.wav")
        if os.path.exists(file_path):
            os.remove(file_path)

        file = await context.bot.get_file(update.message.voice.file_id)
        await file.download_to_drive(file_path)
        await update.message.reply_text("Su audio ha sido recibido, muchas gracias culón 😘💓")
        
        upass = userpass.convert_to_text()
        str1 = upass
        str2 = context.user_data.get('passwd', '')
        similitud_pass = fuzz.ratio(str1, str2)
        print(fuzz.ratio(str1, str2))
        if similitud_pass > 0.8:
            response = requests.get(url)
            print("LED encendido:", response.text)
            await update.message.reply_text("¡Su cerradura se ha abierto exitosamente!")
            # --- EXTRA: logs y bloqueo ---
            if extra_features:
                user = get_user(update.effective_user.id)
                if user:
                    reset_failed_attempts(update.effective_user.id)
                    last_open_time[update.effective_user.id] = datetime.now()
                    add_log(update.effective_user.id, user["username"], user["mac"], str2, "success")
        else:
            await update.message.reply_text("Hubo un error al identificarlo, si realmente es usted, porfavor repita el proceso.")
            if extra_features:
                user = get_user(update.effective_user.id)
                if user:
                    increment_failed_attempts(update.effective_user.id)
                    add_log(update.effective_user.id, user["username"], user["mac"], str2, "fail")
                    msg = handle_blocking(update, user)
                    if msg:
                        await update.message.reply_text(msg)
            return None
    except Exception as e:
        print("Error al procesar el audio:", e)
        await update.message.reply_text("Error al procesar audio")

# ===================== CONFIGURACIÓN DEL BOT =====================
app = ApplicationBuilder().token(TELE_API).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("help", help_command))
app.add_handler(CallbackQueryHandler(palabra_callback, pattern="^palabra_aleatoria$|^palabra_predefinida$"))
app.add_handler(CommandHandler("user", user_command))
app.add_handler(CommandHandler("password", password_command))
app.add_handler(CommandHandler("passwordrandom", passwordrandom_command))
app.add_handler(CommandHandler("logs", logs_command))
app.add_handler(MessageHandler(filters.VOICE, audio_bot))
app.run_polling()
#=======================================================================================================================