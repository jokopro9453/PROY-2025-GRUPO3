import json
import os
from datetime import datetime, timedelta

LOG_FILE = "logs.json"

def load_logs():
    if not os.path.exists(LOG_FILE):
        # Crea el archivo vacío si no existe
        with open(LOG_FILE, "w") as f:
            json.dump([], f)
        return []
    with open(LOG_FILE, "r") as f:
        return json.load(f)

def save_logs(logs):
    with open(LOG_FILE, "w") as f:
        json.dump(logs, f, indent=2)

def add_log(telegram_id, username, mac, password, result):
    logs = load_logs()
    logs.append({
        "telegram_id": telegram_id,
        "username": username,
        "mac": mac,
        "password": password,
        "result": result,
        "timestamp": datetime.now().isoformat(timespec="seconds")
    })
    save_logs(logs)

def get_logs_by_period(period="day"):
    logs = load_logs()
    now = datetime.now()
    if period == "day":
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    elif period == "week":
        start = now - timedelta(days=now.weekday())
        start = start.replace(hour=0, minute=0, second=0, microsecond=0)
    elif period == "month":
        start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    else:
        return []
    return [log for log in logs if datetime.fromisoformat(log["timestamp"]) >= start]